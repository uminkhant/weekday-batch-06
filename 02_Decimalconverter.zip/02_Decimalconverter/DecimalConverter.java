class DecimalConverter{

	static String unit;
	public static void main(String[] args) {
		String string  = decimalToOctalOrHexaOrBinary(267,2);
		int  decimal = binaryOrOctalOrHexaToDecimal(string,2);

		System.out.println("From Decimal : "+string);
		System.out.println("From String : "+decimal);
	}

	static int binaryOrOctalOrHexaToDecimal(String string,int divisor){
		return Integer.parseInt(string,divisor);

	}

	static String decimalToOctalOrHexaOrBinary(int decimal,int divisor){
		String result = "";
		int remainder = 0;
 		char[]array = getArray(divisor);

		while(decimal > 0){
			 remainder = decimal%divisor;
			 result = array[remainder]+result;
			 decimal = decimal/divisor;
		}
		return result;
		//System.out.println(unit + result);

	}

	static  char[] getArray(int divisor){
		char[] binary = {'0','1'};
		char[] octal = {'0','1','2','3','4','5','6','7'};
		char[] hexa = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

		if(divisor == 2){
			unit = "0b";
			return binary;
		}else if(divisor == 8){
			unit = "0";
			return octal;
		}else if(divisor == 16 ){
			unit = "0x";
			return hexa;
		}
		return null;
		
	}
}