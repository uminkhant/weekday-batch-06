class DecimalConverter{

	 int binaryOrOctalOrHexaToDecimal(String string,int divisor){
		return Integer.parseInt(string,divisor);
	}

	 String decimalToOctalOrHexaOrBinary(int decimal,int divisor){
		String result = "";
		int remainder = 0;
 		char[]array = getArray(divisor);

		while(decimal > 0){
			 remainder = decimal%divisor;
			 result = array[remainder]+result;
			 decimal = decimal/divisor;
		}
		return result;
	
	}

	  char[] getArray(int divisor){
		char[] binary = {'0','1'};
		char[] octal = {'0','1','2','3','4','5','6','7'};
		char[] hexa = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

		if(divisor == 2){
			return binary;
		}else if(divisor == 8){
			return octal;
		}else if(divisor == 16 ){
			return hexa;
		}
		return null;
		
	}
}