import java.util.Scanner;

class BinaryConverter{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please type message !");
		String str = sc.nextLine(); 
		String result = converter(str);
		System.out.println(result);
		System.out.println();
	}

	static String converter(String str){
		String[] array = str.split(" ");
		String message = "";

		for(int i = 0 ;i < array.length ;i++){
			 message = message +"\n"+charToBinary(array[i]);
		}
		return message ;
	}

	static String charToBinary(String str){
		String binary = "";
		
		char[] array = str.toCharArray(); 
		for (int i = 0;i < array.length ;i++ ) {
			 int deci = (int)array[i];
			 binary = decimalToBinary(deci)+" " + binary;
			
		}
		return binary ;
	}


	static String decimalToBinary(int decimal){
			String result = "";
			int remainder = 0;

			while(decimal > 0){
				 remainder = decimal%2;
				 result = remainder+result;
				 decimal = decimal/2;
			}
			return result;
		
		}

}