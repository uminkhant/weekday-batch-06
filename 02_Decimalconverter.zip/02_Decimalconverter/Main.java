import java.util.Scanner;
class Main{
	static Scanner sc ;
	static int divisor,i,type,dec;
	static String unit,number;
	
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		DecimalConverter deci = new DecimalConverter();

		greeting("Welcome");
		askAndGetDecimal();
		String s = selectOctalOrHexaOrBinary();
		chooseConvertType(s,deci);
		greeting("Bye Bye");
	}

	static void chooseConvertType(String s,DecimalConverter deci){	
		switch(type){
		case 1:
			String string  = deci.decimalToOctalOrHexaOrBinary(dec,divisor);
			showResult(s,unit+string);
			break;
		case 2:
			int result = deci.binaryOrOctalOrHexaToDecimal(number,divisor);
			showResult(s,result+"");
			break;
		default:
			break;
		}
	}

	static void showResult(String type,String result){
		System.out.println();
		System.out.println("Convert Decimal to "+type+" is : "+result);
	}
	

	static void greeting(String message){
		System.out.println();
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("----------------------------- "+message+" ------------------------------------------");
		System.out.println("-----------------------------------------------------------------------");
		System.out.println();
	}

	static void askAndGetDecimal(){
		System.out.println("""
			Please select One type !
			1.Decimal To B|O|H
			2.B|O|H To Decimal
			""");
		type = sc.nextInt();
		System.out.println("Please type Number !");
		
		if(type == 1){
		 	dec = sc.nextInt();
		}else{
			number = sc.next();
		} 

		System.out.println("""
			Please select one number!
			1.Binary
			2.Octal
			3.Hexa
			""");

		 i = sc.nextInt();
	}

	static String selectOctalOrHexaOrBinary(){
		switch(i){
			case 1:
				divisor = 2;
				unit = "0b";
				return "Binary";
			case 2:
				divisor = 8;
				unit = "0";
				return "Octal";
			case 3:
				divisor = 16;
				unit = "0x";
				return "Hexa";
		}
		return null;
	}

	
}