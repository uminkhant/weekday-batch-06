import java.util.Scanner;
class Main{
	static Scanner sc ;
	static int divisor,i,dec;
	static String unit;
	
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		DecimalConverter deci = new DecimalConverter();

		greeting("Welcome");
		selector();
		String s = convertTo();
		String string  = deci.decimalToOctalOrHexaOrBinary(dec,divisor);
		showResult(s,string);
		greeting("Bye Bye");
	}

	static void showResult(String type,String result){
		System.out.println();
		System.out.println("Convert Decimal to "+type+" is : "+unit+result);
	}
	

	static void greeting(String message){
		System.out.println();
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("----------------------------- "+message+" ------------------------------------------");
		System.out.println("-----------------------------------------------------------------------");
		System.out.println();
	}

	static void selector(){
		System.out.println("""
			Please select one number!
			1.Binary
			2.Octal
			3.Hexa
			""");

		 i = sc.nextInt();
		System.out.println("Please type decimal !");
		 dec = sc.nextInt();		

	}

	static String convertTo(){

		switch(i){
			case 1:
				divisor = 2;
				unit = "0b";
				return "Binary";
			case 2:
				divisor = 8;
				unit = "0";
				return "Octal";
			case 3:
				divisor = 16;
				unit = "0x";
				return "Hexa";
		}
		return null;
	}

	
}