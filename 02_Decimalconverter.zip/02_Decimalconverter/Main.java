import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class Main{
	static int divisor,bohSelector,actionSelector,dec;
	static String unit,string,bohName;
	static DecimalConverter deci ;
	static BufferedReader br;
	
	public static void main(String[] args) {

		deci = new DecimalConverter();
		br = new BufferedReader(new InputStreamReader(System.in));
		greeting("Welcome");
		runProgram();		
		greeting("Bye Bye");
	}

	static void runProgram(){
		String ask = "";
		do{
			askAndGetDecimal();
			selectOctalOrHexaOrBinary();
			chooseConvertType();
			clear();
			System.out.println("Do you want to run again y/other");
			ask = getInput();
		}while(ask.equals("y"));
	}

	

	static void chooseConvertType(){
		String result = "";	
		switch(actionSelector){
			case 1:
				String s  = deci.decimalToOctalOrHexaOrBinary(dec,divisor);
				result = unit+s;
				break;
			case 2:
				int i = deci.binaryOrOctalOrHexaToDecimal(string,divisor);
				result = i+"";
				break;
			case 3:
				 result = deci.stringToBinary(string,divisor);		
				break;
			case 4:
				 result = deci.messageToBinary(string,divisor);		
				break;		
			default:
				break;
		}
		showResult(bohName,result);
	}

	static void showResult(String type,String result){
		System.out.println();
		System.out.println("Convert Decimal to "+type+" is : "+result);
	}
	

	static void greeting(String message){
		System.out.println();
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("----------------------------- "+message+" ------------------------------------------");
		System.out.println("-----------------------------------------------------------------------");
		System.out.println();
	}

	static void askAndGetDecimal() {		
		
		System.out.println("""
			Please select One type !
			 
			 1.Decimal To B|O|H
			 2.B|O|H To Decimal
			 3.String To B|O|H
			 4.Message To B|O|H
			
			""");
		actionSelector = Integer.valueOf(getInput());
		
		if(actionSelector == 1){
			System.out.println("Please type Number !");
		 	dec = Integer.parseInt(getInput());
		}else if(actionSelector == 2 || actionSelector == 3){
			System.out.println("Please type string !");
			string = getInput();
		}else{
			System.out.println("Please type Message !");
			string = getInput();
		}

		System.out.println("""
			Please select one number!
			 
			 1.Binary
			 2.Octal
			 3.Hexa

			""");

		 bohSelector = Integer.parseInt(getInput());		
	}

	static void selectOctalOrHexaOrBinary(){
		switch(bohSelector){
			case 1:
				divisor = 2;
				unit = "0b";
				bohName = "Binary";
				break;
			case 2:
				divisor = 8;
				unit = "0";
				bohName = "Octal";
				break;
			case 3:
				divisor = 16;
				unit = "0x";
				bohName = "Hexa";
				break;
		}	
	}

	static String getInput(){
		String str = "";
		try{
		  str = br.readLine();	
		}catch(IOException ex){
			System.out.println("Something wrong");
		}
		return str;
	}

	static void clear(){
		divisor = 0;
		bohSelector = 0;
		actionSelector = 0;
		dec = 0;
		unit = null;
		string = null;
	}

	
}