import pkgOne.Person;

class Main{

	public static void main(String[] args) {
			Person p = new Person();

			//.p.name = "SS";

			p.setGender("Male");
			p.setName("Soe Thu");
			p.setAge(23);
			System.out.println(p.getName()+"\t"+p.getAge());

			Person p1 = new Person();
			p1.setGender("ww");
			p1.setName("Sandar");
			p1.setAge(12);
			System.out.println(p1.getName()+"\t"+p1.getAge());
	}
}