package pkgOne;

public class Person{

	 String name ;
	 int age;
	 String gender;

	public void setName(String name){
		if(gender.equals("Male")){
			this.name = "Mg."+name ;
		}else{
			this.name = "Ma."+name;
		}
	}

	public String getName(){
		return name;
	}

	public void setAge(int age){
		this.age = age;
	}

	public int getAge(){
		return age;
	}

	public void setGender(String gender){
		this.gender = gender;
	}

	public String getGender(){
		return gender;
	}


}