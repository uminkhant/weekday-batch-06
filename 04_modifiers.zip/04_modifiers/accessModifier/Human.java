package accessModifier;

public class Human {

	private String privateData;
	String defaultData;
	protected String protectedData;
	public String publicData;
}