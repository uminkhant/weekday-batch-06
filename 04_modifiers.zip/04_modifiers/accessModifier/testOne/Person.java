package accessModifier.testOne;
import accessModifier.Human;

public class Person extends Human{

	
}