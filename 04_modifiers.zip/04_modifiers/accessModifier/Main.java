package accessModifier;
import accessModifier.testOne.Person;
public class Main  {
	public static void main(String[] args) {
		Human human = new Human();
		//human.privateData = "Private Data ";
		human.defaultData = "Default Data";
		human.protectedData = "Protected Data";
		human.publicData = "Public Data";

		Person person = new Person();
		person.protectedData = "Protected Data";
		person.publicData = "Public Data";

	}
}