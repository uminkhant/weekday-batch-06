package resources.services;

import resources.entity.Student;

public class StudentService{

	private Student[]students = new Student[0];

	public void addStudent(Student student){
		Student[]temp = new Student[students.length+1];
		for(int x = 0 ;x < students.length; x++){
			temp[x] = students[x];
		}
		temp[students.length] = student;
		students = temp;

	}

	public Student[] getStudents(){
		return students;
	}
}