class InheritanceDemo{

	public static void main(String[] args) {
		
		B b = new B();
		b.doSomething();
		

	}
}

class A {
	private String name;

	A(String name){
		this.name = name;
	}
	void doSomething(){
		System.out.println("Do Something");
	}
}

class B extends A{
	B(){
		super("Sss");
	}
}