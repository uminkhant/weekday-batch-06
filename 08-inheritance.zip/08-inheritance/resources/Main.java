import java.util.Scanner;
class Main{
	static Scanner sc;
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		System.out.println("Type obj name !");

		String name = sc.next();
		Shape s = getShape(name);
		s.draw();
	}

	static Shape getShape(String name){
		switch(name){
		case"circle":
			return new Circle();
		case"square":
			return new Square();
		default:
			return new Shape();
		}
	}
}

class Shape{

	void draw(){
		System.out.println("drawing something");
	}
}

class Circle extends Shape{
	@Override
	void draw(){
		System.out.println("drawing Circle");
	}
}
class Square extends Shape{
	@Override
	void draw(){
		System.out.println("drawing Square");
	}
}