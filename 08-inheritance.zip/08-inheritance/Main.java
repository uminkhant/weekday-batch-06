import pkgOne.*;

class Main{
	public static void main(String[] args) {
		
		// Shape s = new Triangle("Trangle");
		// s.showArea();
		// s.getNumber();

		A a = new B("Test");

	}
}

class A{
	public A(String name){
		System.out.println("Parent :"+name);
	}
}

class B extends A{
	B(String name){
		super(name);
	}
}
