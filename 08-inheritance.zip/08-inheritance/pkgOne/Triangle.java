package pkgOne;

public class Triangle extends Shape{

	 Triangle(String name){
		super(name);
	}
	
	@Override
	 public void showArea(){
		System.out.println("Using from Triangle class ");
		
	}

	@Override
	public Integer getNumber(){
		return 0;
	}
}