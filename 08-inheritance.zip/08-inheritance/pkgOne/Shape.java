package pkgOne;
public  class Shape{
	
	 String name ;

	public Shape(String name){
	 	this.name = name;
	 }

	 public  void showArea(){
		System.out.println("Using from Shape class "+name);
		
	}

	public Number getNumber(){
		return 0;
	}
}