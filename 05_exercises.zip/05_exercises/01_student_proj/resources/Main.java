package resources;
import resources.entity.Student;
import java.util.Scanner;

public class Main{

	private static Scanner sc;
	private static Student student;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		Main m = new Main();
		m.greeting("Welcome To Student Project");
		m.setData();
		m.showData();
		m.showData();
		m.greeting("Bye Bye");
		
	}

	void greeting(String message){
		System.out.println("------------------------------------------------------------------");
		System.out.println("   ===========  "+message+"    ============    ");
		System.out.println("------------------------------------------------------------------");
	}

	void setData(){
		System.out.println("Please type name !");
		String name = sc.nextLine();
		System.out.println("Please type St'street");
		String street = sc.nextLine();
		System.out.println("Please type St'township");
		String township = sc.nextLine();
		System.out.println("Please type St'city");
		String city = sc.nextLine();
		System.out.println("Please type age !");
		int age = sc.nextInt();
		
		student = new Student(name,age,street,township,city);
		
	}
	void showData(){	
		System.out.println();
		System.out.print("Name : "+student.getName());
		System.out.print(" Age : "+student.getAge());
		System.out.print(" Street : "+student.getStreet());
		System.out.print(" Township : "+student.getTownship());
		System.out.print(" Citye : "+student.getCity());
		System.out.println();
	}
}