
class Person{

	static int staticCount;
	int instanceCount;
	String name;

	void doSomething(String str){
		//return "Hello";
	}

	void setName(String name){
		this.name = name;
	}

	void show(){
		System.out.println("Name  : "+name);
	}
	
}