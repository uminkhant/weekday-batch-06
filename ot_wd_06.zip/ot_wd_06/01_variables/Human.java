class Human{

	public static void main(String[] args) {
		
		Person p1 = new Person();
		// p1.instanceCount = 20;
		// p1.staticCount = 30;
		
		p1.setName("Aung Aung");
		p1.show();
		p1.doSomething("sss",34);

		/*System.out.println("person 1 :"+p1.instanceCount);
		System.out.println("person 1 :"+p1.staticCount);
		Person p2 = new Person();
		System.out.println("person 2 :"+p2.instanceCount);
		System.out.println("person 2 :"+p2.staticCount);*/

	}
}