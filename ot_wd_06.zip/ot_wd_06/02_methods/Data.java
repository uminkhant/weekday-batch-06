class Data{
	// static String staticString;
	// String instanceString;
	String name;
	static int count;

	void setName(String name){
		this.name = name;
	}

	void countUp(){
		count ++;
	}

	int getCount(){
		return count;
	}

	String getName(){
		return name;
	}

	// void instanceMethod(){
	// 	Data.staticString = "static String";
	// 	instanceString = "instance Stirng ";
	// 	System.out.println("Using instance method");
	// }
	// static void staticMethod(){
	// 	Data.staticString = "static String";
	// 	//instanceString = "instance Stirng ";
	// 	System.out.println("Using static method");
	// }
}