class MethodDemoThree{

	public static void main(String[] args) {
		Data d1 = new Data();
		d1.setName("John");
		d1.countUp(); 
		System.out.println("Counter Number : "+d1.getCount()+"  Name : "+d1.getName());
		
		Data d2 = new Data();
		d2.setName("Willaim");
		d2.countUp();
		System.out.println("Counter Number : "+d2.getCount()+"  Name : "+d2.getName());
	}
}