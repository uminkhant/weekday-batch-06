public class ConstructorDemo{
	public static void main(String[] args) {
		
		// Human h = new Human();
		// h.show();
		Human.doSomething();
	}
}

class Human{


	static{
		System.out.println("Hello static block");
	}
	{
		System.out.println("Hello instance block");
	}
	Human(){
		System.out.println("Hello constructor");
	}

	static void doSomething(){
		System.out.println("Hello static something");
	}

	void show(){
		System.out.println("Show something");
	}
}