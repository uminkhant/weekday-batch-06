class MethodDemoTwo{

	public static void main(String[] args) {
		Data d = new Data();
		d.instanceMethod();
		
		Data.staticMethod();
		d.staticMethod();
	}

	void doSomething(){
		Data d = new Data();
		d.instanceMethod();
	}
}