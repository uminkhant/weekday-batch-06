class MethodDemo{

	static String name;
	int age;

	public static void main(String[] args) {
		// MethodDemo demo = new MethodDemo();
		// demo.setData("William",42);
		// String s = demo.getName();
		// int a = demo.getAge();

		// System.out.println("Name : "+s);
		// System.out.println("Age : "+a);
		name = "Willam";
		
	}

	 void setData(String name,int age){
		this.name = name;
		this.age = age;
	}

	 String getName(){
		return name;
	}

	 int getAge(){
		return age;
	}

	 void setModifiedName(){
		name = "Hello "+name;
	}

}